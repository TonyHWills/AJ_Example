-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Host: localhost
-- Generation Time: Dec 19, 2022 at 05:15 AM
-- Server version: 8.0.31
-- PHP Version: 7.4.30

-- ~ I BELIEVE MY ISSUES WITH QUERYING NORMALIZED DB MIGHT ORIGINATE HERE ~
SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `final_camping_database`
--

-- --------------------------------------------------------

--
-- Table structure for table `item_inventory`
--

CREATE TABLE `item_inventory` (
  `itemID` int UNSIGNED NOT NULL,
  `itemName` varchar(255) COLLATE utf8mb4_general_ci NOT NULL,
  `itemType` varchar(255) COLLATE utf8mb4_general_ci NOT NULL,
  `image` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `item_inventory`
--

INSERT INTO `item_inventory` (`itemID`, `itemName`, `itemType`, `image`) VALUES
(9, 'Super Solar', 'Solar Panel', 'testingSuper Solar.jpg'),
(10, 'Master Generator', 'Generator', 'testingMaster Generator.jpg'),
(11, 'firewood', 'firewood', 'testingfirewood.jpg'),
(12, 'Solar Camera', 'Camera', 'testingSolar Camera.jpg'),
(13, 'Unlimited Money Cheat', 'IRL', 'testingUnlimited Money Cheat.jpg');

-- --------------------------------------------------------

--
-- Table structure for table `item_ownership`
--

CREATE TABLE `item_ownership` (
  `ownershipIDNumber` int UNSIGNED NOT NULL,
  `itemID` int UNSIGNED NOT NULL,
  `userID` int UNSIGNED NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `userID` int UNSIGNED NOT NULL,
  `firstName` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `lastName` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `username` varchar(255) COLLATE utf8mb4_general_ci NOT NULL,
  `password` varchar(255) COLLATE utf8mb4_general_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`userID`, `firstName`, `lastName`, `username`, `password`) VALUES
(6, 'test', 'test', 'test', '$2y$10$tjW0RDH1pSHLGWyR8NPDmujHFPhLKQjD/L3dtUyIet9Kw.Wvo2gYG'),
(7, 'rrr', 'rrr', 'rrr', '$2y$10$P90YI1ywMCnaioeZRD6EWu1O4qsBFJvh3LdhRYBN5Iduk8aRO0o5y'),
(8, 'add', 'add', 'add', '$2y$10$Y1w1ESegDfIITy7UFz59V.9Gv0SbXUgWsX/Fvmiusoa2pZLcmjorq'),
(9, 'testing', 'testing', 'testing', '$2y$10$fPelT9oL3uGObDIv/YX/vOZAnAb8DGhazcPedXLYLjVbq/7g53uuu');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `item_inventory`
--
ALTER TABLE `item_inventory`
  ADD PRIMARY KEY (`itemID`);

--
-- Indexes for table `item_ownership`
--
ALTER TABLE `item_ownership`
  ADD PRIMARY KEY (`ownershipIDNumber`),
  ADD FOREIGN KEY `itemID` (`itemID`),
  ADD FOREIGN KEY `userID` (`userID`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`userID`);

--
-- AUTO_INCREMENT for dumped tables
--
-- ~ I BELIEVE MY ISSUES WITH QUERYING NORMALIZED DB MIGHT ORIGINATE HERE ~
--
-- AUTO_INCREMENT for table `item_inventory`
--
ALTER TABLE `item_inventory`
  MODIFY `itemID` int UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=14;

--
-- AUTO_INCREMENT for table `item_ownership`
--
ALTER TABLE `item_ownership`
  MODIFY `ownershipIDNumber` int UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `userID` int UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `item_ownership`
--
ALTER TABLE `item_ownership`
  ADD CONSTRAINT `item_ownership_ibfk_1` FOREIGN KEY (`itemID`) REFERENCES `item_inventory` (`itemID`),
  ADD CONSTRAINT `item_ownership_ibfk_2` FOREIGN KEY (`userID`) REFERENCES `users` (`userID`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
