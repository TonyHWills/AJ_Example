// I could use ALOT of practice with JS, if you cant tell. I tend to struggle with JS more than other languages.
// I do understand how to render things in html via JS like this, but I hear conflicting opinions on whether this is could practice, not that I know any other way yet to change info based on user sign-in, etc
let userContentVar = document.getElementById("currentUserDiv");
let invContainer = document.getElementById("invContainer");
let signOutBtn = document.getElementById("signOutBtn");
let signInBtn = document.getElementById("signInBtn");
let signUpBtn = document.getElementById("signUpBtn");
let invBtn = document.getElementById("invBtn");
let sideContentDiv = document.getElementsByClassName("sideContentDiv");
fetch('verifyAuth.php').then(response => response.json()).then(function(data){
    if(data.auth){
        userContentVar.innerHTML = "Welcome back " + data.username;
        signInBtn.remove();
        signUpBtn.remove();
        sideContentDiv.innerText = "NO ADS ON SIGN IN";
        
    } else {
        userContentVar.innerHTML= "Please sign in!";
        
        
 
        signOutBtn.remove();
        invBtn.remove();
    }});
    
    fetch("inventoryViews.php").then(response=>response.json()).then(data=>data.forEach(item => itemFunction(item)));
function itemFunction(item){
    let itemContainer = document.createElement("div");
    itemContainer.setAttribute("class", "item");

    let pictureCol = document.createElement("div");
    pictureCol.setAttribute("class", "itemCol");

    let itemPic = document.createElement("img");
    itemPic.setAttribute("class", "itemPic");
    itemPic.setAttribute("src", `images/${item.image}`);

    pictureCol.appendChild(itemPic);
    itemContainer.appendChild(pictureCol);



    let itemInfo = document.createElement("div");
    itemInfo.setAttribute("class", "itemColumn");
    
    let itemName = document.createElement("h1");
    itemName.innerHTML = "Item Name:" + item.itemName;
    itemName.setAttribute("class", "iName");
    
    let itemType = document.createElement("h2");
    itemType.innerHTML = "Item Name:" + item.itemType;
    itemType.setAttribute("class", "iType");

    itemInfo.appendChild(itemName);
    itemInfo.appendChild(itemType);
    itemContainer.appendChild(itemInfo);
    invContainer.appendChild(itemContainer); 
}