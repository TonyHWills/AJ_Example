<?php 
//For Database Connection
require_once "config.php";

//Conditional For All Values Set
if(isset($_POST['firstName']) && isset($_POST['lastName']) && isset($_POST['username']) && isset($_POST['password'])){
    $firstName = $_POST['firstName'];
    $lastName = $_POST['lastName'];
    $username = $_POST['username'];
    $password = password_hash($_POST['password'], PASSWORD_DEFAULT);
    $userID = NULL;

    $conn = new mysqli($hn,$un,$pw,$db);

    if ($conn->connect_error) die("Fatal error on connect");

    $stmt= $conn->prepare('INSERT INTO users VALUES(?,?,?,?,?)');
    $stmt->bind_param('issss',$userID,$firstName,$lastName,$username,$password);
    $stmt->execute();
    $stmt->close();
    $conn->close();

    header('Location: ../signin.html');
}
?>