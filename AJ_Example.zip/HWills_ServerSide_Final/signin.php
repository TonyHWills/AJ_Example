<?php
require_once "config.php";
if (isset($_POST['username']) && isset($_POST['password'])){
    $username = $_POST['username'];
    $password = $_POST['password'];
    $userID = $_POST['userID'];


    $conn = new mysqli($hn,$un,$pw,$db);

    $query = "SELECT * FROM users WHERE username='$username'";
    
    $result = $conn->query($query);
    if(!$result) die("Database access failed");

    foreach($result as $item){
        if(password_verify($password, $item['password'])){
            session_start();
            // Question I haven't found the answer to on Stack, or in documentation:
            // Is this where you set "session variables to be used throught the program based on information in the database?
            // I had got this to work, but when I wanted to try using first names vs usernames, I couldnt get it too work. Feel I'm missing a peice of logic here.
            $_SESSION['username'] = $username;
            $_SESSION['password'] = $password;
            
            header('Location: index.html');
        }
        else {
            echo "!~~Invalid Password~~!";
        }
    }
}
?>
