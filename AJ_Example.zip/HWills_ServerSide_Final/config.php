<?php 
//Host
$hn = 'localhost';

//User
$un = 'root';

//Password
$pw = 'mysql';

//Database
$db = 'final_camping_database';
?>