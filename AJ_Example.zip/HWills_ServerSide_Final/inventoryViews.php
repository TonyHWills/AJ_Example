<?php

require_once "config.php";

$conn = new mysqli($hn, $un, $pw, $db);
if ($conn->connect_error){
    die("Failed to load inventory");
}

session_start();


$query = "SELECT * FROM item_inventory";
$result = $conn->query($query);

$items = array(); 
foreach($result as $item){
    $items[] = $item;
}

echo json_encode($items);

?>