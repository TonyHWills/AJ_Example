<?php

require_once "config.php";
require_once "utils.php";

if(isset($_POST['itemName']) && isset($_POST['itemType']) && $_FILES){
    $conn = new mysqli($hn,$un,$pw,$db);

    $itemName = sanitize($conn, $_POST['itemName']);
    $itemType = sanitize($conn, $_POST['itemType']);
    $itemID = NULL;

    session_start();
    $username = $_SESSION['username'];

    $query = "SELECT userID FROM users WHERE username = '$username'";
    $result = $conn->query($query);

    $rows = $result->num_rows;

    foreach($result as $aItem){
        $itemOwnerID = $aItem['userID'];
    }

    switch($_FILES['image']['type']){
        case 'image/jpeg': $ext = 'jpg'; break;
        case 'image/gif': $ext = 'gif'; break;
        case 'image/png': $ext = 'png'; break;
        case 'image/tiff': $ext = 'tiff'; break;
        default:           $ext = ''; break;
    }

    if($ext){
        $image = "$username$itemName.$ext";
        $n = "images/$image";
        move_uploaded_file($_FILES['image']['tmp_name'], $imagefolder . $n);
    }

    $stmt = $conn->prepare('INSERT INTO item_inventory VALUES(?,?,?,?)');
    $stmt->bind_param('isss', $itemID, $itemName, $itemType, $image);
    $stmt->execute();
    $itemID = $conn->insert_id;
    $stmt->close();

    $stmt = $conn->prepare('INSERT INTO item_ownership VALUES(?,?,?)');
    $stmt->bind_param('iii', $ownershipIDNumber,$itemID,$userID);
    $stmt->execute();
    $stmt->close();
    $conn->close();


    $_SESSION['statusType'] = "success";
    $_SESSION['statusMessage'] = "Item Added.";

    header('location: inventoryView.html');
    

}